SmartHost Demo — Static Template
--------------------------------
Files in this zip:
- index.html
- styles.css
- script.js
- /assets/logo.svg
- /assets/hero.jpg
- /assets/map.jpg

How to use:
1. Unzip the folder.
2. Open index.html in a browser or upload the folder to your web host.
3. For a contact form you will need to connect a backend or a service (Formspree, Netlify Forms, etc).

Notes:
- Bootstrap is loaded via CDN. If you need fully offline, replace CDN links with local files.
- Customize text, colors, and pricing in the HTML and CSS.
